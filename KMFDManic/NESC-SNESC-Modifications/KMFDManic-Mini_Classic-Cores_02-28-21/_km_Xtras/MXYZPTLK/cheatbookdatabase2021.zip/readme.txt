CheatBook-DataBase 2021 v1.0

CheatBook-DataBase 2021 is a freeware "cheat-code tracker" that makes hints and 
cheats (for PC, Walkthroughs, Playstation, Playstation 2, Playstation 3, Sega, 
Nintendo 64, DVD, Gameboy Advance, Gameboy Color, N-Gage, Nintendo DS, PSP, Xbox,
Wii, Wii U, iPhone, Gamecube, Dreamcast, Xbox 360, Super Nintendo, Playsttaion 4,
XBox One) easily accessible from one central location. If you're an avid gamer 
and want a few extra weapons or lives to survive until the next level, this 
freeware cheat database can come to the rescue. 

Covering more the 25.700 Cheats and Hints for Games, this database represents all
genres and focuses on recent releases. 

Games are listed alphabetically in the left-hand window. 
When you click on a game name, the relevant cheat is displayed in a editor  
window, with convenient buttons that let you print the selection or save any 
changes you've made.

In the latest past many users of the CheatBook-DataBase and readers of the monthly
being published magazine have sent to us small error messages and suggestions for 
improvement again and again. First of all we say "Thank you very much!" to all of you!

Due to this assistance and the permanent sending in of new and revised cheats the 
CheatBook is ever increasing and becoming more and more voluminous.
 
Many of the suggestions which we received are now realized in the new version 2021.

- comfortable adding of individual cheats
- cheats can be edited more easily now
- files and images can be stored 
- simple survey of informations about the cheat
- statistics
- comfortable filter conditions
- consoles cheats added
- 21 different consoles now possible 
- search machine was revised
- link manager
- history log
- News and Updates 
- private user data base
- Import old Own Bases

In order to arrange the program better, more comfortable and more efficient also in
future, we are further on in need of your ideas and suggestions for improvement
So if you have a suggestion for a new feature, if you have found a bug, or if you 
know software archives in which the CheatBook-DataBase is not yet provided for 
download, just write and let us know.

The program is small and setup is a snap. Once CheatBook-Database is on your hard 
drive, use it as much as you want because it's free.
 
Release date: January 10, 2021 - CheatBook-DataBase 2021 is Freeware for 
Win95/98/2000/NT/XP/Vista/Windows 7/Windows 8/ Windows 10.
All Cheats inside from first CHEATBOOK Jan.98 until today.
 
http://www.cheatbook.de
http://www.cheatinfo.de
http://www.cheatchannel.com