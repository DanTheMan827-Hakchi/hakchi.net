TUSH: The Utility for SNES Headers
  v1.1.1 - September 12, 2009
  by Killa B

Usage
=====
  Run tush.exe, click "Browse", and load a rom. If you want to remove a header,
  click "Remove Header". If you want to add a header, click "Add Header".

  The program will automatically detect headers, so you don't have to worry
  about removing one that doesn't exist, or adding one that already exists.

  If, after reading this, you still can't figure out how to use this program,
  you're a fucking idiot and should be ashamed of yourself.

Compiling
=========
  If you're running Linux, you can compile with "make", and install with
  "make install". You'll need to have wxWidgets installed.

  If you're on FreeBSD, I honestly don't know if you can compile it. Feel free
  to try it, though.

  If you're on a Mac, I'm pretty sure you can't compile it. I'm hoping I'll be
  able to work something out for Mac users in the future.
