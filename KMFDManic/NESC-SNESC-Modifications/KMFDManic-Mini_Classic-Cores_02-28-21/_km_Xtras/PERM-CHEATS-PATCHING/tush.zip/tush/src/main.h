#ifndef INC_MAIN_H
#define INC_MAIN_H

#define msgBox(message, title, style) wxMessageBox(wxT(message), wxT(title), style)

#endif /* INC_MAIN_H */

