
Castlevania: Order of Ecclesia Nonlinear
By LagoLunatic

This is a patch for Castlevania: Order of Ecclesia that makes the game much less linear. It opens up the overworld, allowing you to access any area from the start of the game (except Dracula's Castle - you still need to rescue all 13 villagers to unlock the castle).

It also removes several gates in Dracula's Castle that prevented sequence breaking, and modifies some cutscenes to allow you to view them in any order you can access them.

This patch only works on the North American version of Order of Ecclesia.

Patching instructions:
Use a program like Lunar IPS to apply the .ips patch to the game ROM.
