
Castlevania: Dawn of Sorrow Fixed Luck
By LagoLunatic

The luck stat is bugged in Dawn of Sorrow and has almost no effect on drops. Even a full 99 points of luck only increases drop chances by a small fraction of a percent.

This patch fixes luck so that each point increases soul and item drop chances by +0.1%.

This patch only works on the North American version of Dawn of Sorrow.

Patching instructions:
Use a program like Lunar IPS to apply the .ips patch to the game ROM.
