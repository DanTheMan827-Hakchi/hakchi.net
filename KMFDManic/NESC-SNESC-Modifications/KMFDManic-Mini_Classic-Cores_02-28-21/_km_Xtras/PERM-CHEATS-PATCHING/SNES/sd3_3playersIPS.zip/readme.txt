This simple hack adds 3 player support to a game that really should've had it to begin with.
Simply press start on the 3rd controller and away you go!

NOTE: Player 2 must also be enabled to use player 3 at this time (so if you want to play with
only 2 people, use controllers 1 and 2, otherwise use controllers 1 2 and 3).

IPS patches can be applied with snesTool or any other IPS patching tool, I reccomend zophar's domain
for finding these tools if you don't already have them (www.zophar.net)

This hack provided courtesy of Chris Friesen
Send questions/comments to parlance@wafflemind.net

Enjoy!