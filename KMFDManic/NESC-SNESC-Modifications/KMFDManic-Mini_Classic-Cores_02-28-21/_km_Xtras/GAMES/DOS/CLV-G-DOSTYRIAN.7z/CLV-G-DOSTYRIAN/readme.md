-----------------------
Name: DOS: Tyrian
Version: 5-18-19
Creator: KMFDManic/Beylie
Category: Games
-----------------------
=== DOS: Tyrian: Eclipse Software ===

**Prerequisite: Install DOSBox SVN Core**

![Test Image 1](https://i.imgur.com/OZ72Yjh.png)

Tyrian is a scrolling shooter computer game developed by Eclipse Software and published in 1995 by Epic MegaGames. The game was re-released as freeware in 2004, and the graphics were made available under an open content license in April 2007.

The incredible music was composed by Alexander Brandon

Hakchi module system by madmonkey

RetroArch Xtreme + HMODS maintained by KMFDManic/madmonkey/pcm

NES/SNES Mini shell integration by Cluster

Hakchi CE by Team Shinkansen (DanTheMan827/princess_daphie/skogaby/madmonkey)

(c) 2016-20xx
