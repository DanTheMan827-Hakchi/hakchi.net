Copy your modules (*.hmod files or *.hmod folders) here.
