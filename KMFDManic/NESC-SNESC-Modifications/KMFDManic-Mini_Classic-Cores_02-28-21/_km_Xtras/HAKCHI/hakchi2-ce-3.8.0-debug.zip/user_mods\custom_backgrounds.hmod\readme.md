---
Name: Custom Backgrounds
Creator: DanTheMan827
Category: UI
---
This mod will simply transfer your custom borders in `/var/lib/hakchi/rootfs/usr/share/backgrounds` so it can be merged with the main backgrounds folder.

If you're using USB-HOST, you can add your custom borders in `USB:\hakchi\backgrounds`.

## Note

> When you uninstall this mod, it will remove all custom borders you've transferred to `/var/lib/hakchi/rootfs/usr/share/backgrounds`
