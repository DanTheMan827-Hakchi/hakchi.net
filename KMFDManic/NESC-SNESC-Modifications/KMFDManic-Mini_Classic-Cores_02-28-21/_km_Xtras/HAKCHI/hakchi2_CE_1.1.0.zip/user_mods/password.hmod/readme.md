------------------------------
Name: Password Protection Hack
Creator: Cluster
Category: System
------------------------------
This module adds password protection to NES/SNES Mini. Default password is Konami Code :)
