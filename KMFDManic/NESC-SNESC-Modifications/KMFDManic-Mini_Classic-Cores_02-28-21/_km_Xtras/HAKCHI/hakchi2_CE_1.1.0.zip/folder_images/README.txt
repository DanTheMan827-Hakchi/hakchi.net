Copy your folder icons set here in PNG format, up to 204x204.
