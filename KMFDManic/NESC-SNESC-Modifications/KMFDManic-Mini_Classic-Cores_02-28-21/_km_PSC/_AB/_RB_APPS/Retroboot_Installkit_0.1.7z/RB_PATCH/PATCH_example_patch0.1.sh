#!/bin/sh

# RetroBoot Patch - example_patch0.1 
# Example InstallKit setup.

# --------------------------------------------------
# Patch Configuration 
# --------------------------------------------------

# Patch name and version - displayed in install logs
patchname="example_patch"
patchversion="0.1"

# App name as displayed in playlist
app_playlist_label="InstallKit Example"

# App description (displayed as core name)
app_playlist_description="Example InstallKit Application Description"

# App folder - Moved from /RB_PATCH/ to /retroarch/apps/
# Should contain installkit_icon.png (icon for app)
app_folder="example"

# Launcher script - located in app folder
app_launch_script="launchexample.sh"

# Actions run at end of install
custom_install_actions()
{
	echo "Installed InstallKit Example App" >> /media/retroarch/logs/example.log	
}

# --------------------------------------------------
# InstallKit Functions
# --------------------------------------------------

patchlog()
{
	echo "$1" >> $RB_PATCHLOG 
}

writelauncher()
{
	LAUNCHER_FILENAME="/media/retroarch/retroboot/applaunchers/$app_folder.rblauncher"

	if [ ! -d /media/retroarch/retroboot/applaunchers ]; then
		mkdir /media/retroarch/retroboot/applaunchers
	fi

	if [ ! -f "$LAUNCHER_FILENAME" ]; then
		patchlog "  Deleting old launcher"
		rm "$LAUNCHER_FILENAME"
	fi

	echo "# Retroboot App Launcher" >> $LAUNCHER_FILENAME
	echo "" >> $LAUNCHER_FILENAME
	echo "LAUNCHER_LABEL=\"$app_playlist_label\"" >> $LAUNCHER_FILENAME
	echo "LAUNCHER_DESCRIPTION=\"$app_playlist_description\"" >> $LAUNCHER_FILENAME
	echo "LAUNCHER_SCRIPT_PATH=\"/media/retroarch/apps/$app_folder/$app_launch_script\"" >> $LAUNCHER_FILENAME
	
	touch /media/retroarch/retroboot/applaunchers/.updatelaunchers

	patchlog "  Created launcher at $LAUNCHER_FILENAME"
	patchlog "--- Launcher Contents ---"
	cat $LAUNCHER_FILENAME >> $RB_PATCHLOG
	patchlog "---- End of Launcher ----"
}

writeicons()
{
	if [ -f "/media/RB_PATCH/$app_folder/installkit_icon.png" ]; then
		
		if [ -f "/media/retroarch/thumbnails/Applications/Named_Boxarts/$app_playlist_label.png" ]; then
			rm "/media/retroarch/thumbnails/Applications/Named_Boxarts/$app_playlist_label.png"
		fi	
		if [ -f "/media/retroarch/thumbnails/Applications/Named_Snaps/$app_playlist_label.png" ]; then
			rm "/media/retroarch/thumbnails/Applications/Named_Snaps/$app_playlist_label.png"
		fi	
		if [ -f "/media/retroarch/thumbnails/Applications/Named_Titles/$app_playlist_label.png" ]; then
			rm "/media/retroarch/thumbnails/Applications/Named_Titles/$app_playlist_label.png"
		fi	
		
		cp "/media/RB_PATCH/$app_folder/installkit_icon.png" "/media/retroarch/thumbnails/Applications/Named_Boxarts/$app_playlist_label.png"
		cp "/media/RB_PATCH/$app_folder/installkit_icon.png" "/media/retroarch/thumbnails/Applications/Named_Snaps/$app_playlist_label.png"
		mv "/media/RB_PATCH/$app_folder/installkit_icon.png" "/media/retroarch/thumbnails/Applications/Named_Titles/$app_playlist_label.png"
		patchlog "  Installed app icons"
	else
		patchlog "  WARNING: No app icon found!"
	fi
}


# InstallKit Main Routine

patchlog "  InstallKit for $app_playlist_description started"

if [ ! -d "/media/RB_PATCH/$app_folder" ]; then
	patchlog "  FAIL: Install data not found ($app_folder).  Aborting patch."
	exit 1
fi

if [ -e "/media/retroarch/apps/$app_folder" ]; then
	patchlog "  Deleting old app folder"
	rm -rf "/media/retroarch/apps/$app_folder"
fi

if [ ! -d /media/retroarch/apps ]; then
	mkdir /media/retroarch/apps
fi

if [ ! -d /media/retroarch/retroboot/applaunchers ]; then
	mkdir /media/retroarch/retroboot/applaunchers
fi

patchlog "  Adding $app_playlist_label to Apps menu"
writelauncher

patchlog "  Creating icons"
writeicons

patchlog "  Moving app folder"
mv "/media/RB_PATCH/$app_folder" "/media/retroarch/apps/$app_folder"

patchlog "  Running custom install actions"
custom_install_actions
	
patchlog "  SUCCESS: $patchname version $patchversion installed successfully."
