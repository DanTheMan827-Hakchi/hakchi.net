#!/bin/sh

echo "Launched InstallKit Example App" >> /media/retroarch/logs/example.log